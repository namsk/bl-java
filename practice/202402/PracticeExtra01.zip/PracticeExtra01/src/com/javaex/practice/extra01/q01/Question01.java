package com.javaex.practice.extra01.q01;

public class Question01 {
	public void printAnswer(int toNum) {
		//	TODO: 이곳에 해답을 작성합니다.
		
	}
}
