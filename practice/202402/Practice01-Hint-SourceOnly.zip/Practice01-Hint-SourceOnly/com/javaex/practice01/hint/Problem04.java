package com.javaex.practice01.hint;

public class Problem04 {

	public static void main(String[] args) {

		for (int i = 1;   ; i++) { //세로축 반복조건
			
		    //가로축 반복조건
			System.out.println();
		}
		
	}

}
