package com.javaex.problem05;

public class Cat implements Soundable {


}
