package com.javaex.problem05;

public class Dog implements Soundable {


}
