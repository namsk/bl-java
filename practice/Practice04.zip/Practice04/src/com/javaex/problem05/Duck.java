package com.javaex.problem05;

public class Duck implements Soundable {


}
