package com.javaex.problem04;

public class Sparrow extends Bird {



}
