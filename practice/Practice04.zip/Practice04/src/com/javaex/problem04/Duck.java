package com.javaex.problem04;

public class Duck extends Bird {

    public void sing() {
    
    }

    public void fly() {
    
    }
    
    public void showName() {
    
    }

}
