package com.javaex.problem02;

public class Depart extends Employee {

    //코드작성

}
