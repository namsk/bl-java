package com.javaex.problem03;

public class Phone {

    public void execute(String str){
        call();
    }
    
    private void call(){
        System.out.println("통화기능시작");
    }
}
