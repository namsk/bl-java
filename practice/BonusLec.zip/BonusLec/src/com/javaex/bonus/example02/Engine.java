package com.javaex.bonus.example02;

public interface Engine {
	public void turnOn();
	public void run();
	public void stop();
	public void turnOff();
}
