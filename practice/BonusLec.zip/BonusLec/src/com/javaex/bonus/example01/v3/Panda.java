package com.javaex.bonus.example01.v3;

public class Panda extends Animal {

	public Panda(String name) {
		super(name);
	}
	

}
