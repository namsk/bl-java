package com.javaex.bonus.example01.v5;

public interface KungFu {
	public void kungfu();
}
