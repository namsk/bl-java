package com.javaex.bonus.example01.v5;

public interface Drive {
	public void drive();
}
