package com.javaex.bonus.example01.v2;

public class StageApp {

	public static void main(String[] args) {
		MatrixPerson p = new MatrixPerson("NEO");
		p.speak();
		
		//	이제 MatrixPerson NEO는 쿵후를 할 수 있게 되었습니다.
		p.kungfu();
		
		//	네오에게 운전을 가르쳐 봅시다. -> v3
	}

}
