package com.javaex.bonus.example01.v5;

public interface Talkable {
	public void speak();
}
