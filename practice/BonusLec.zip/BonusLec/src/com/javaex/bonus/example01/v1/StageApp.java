package com.javaex.bonus.example01.v1;

public class StageApp {

	public static void main(String[] args) {
		MatrixPerson p = new MatrixPerson("NEO");
		p.speak();
		
		//	MatrixPerson에게 쿵후를 가르쳐 줍시다. -> v2
	}

}
