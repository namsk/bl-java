package com.javaex.practice01.hint;

public class Problem03 {
	
	public static void main(String[] args){
		
		for () { //가로 반복조건
			for () { //세로 반복조건
				System.out.print(dan +"*"+ i + "=" + dan*i);
				System.out.print("\t");
			}
			
			System.out.println();
		}
		
	}

}
