package com.javaex.problem01;

public class Mul extends Operator {


}
