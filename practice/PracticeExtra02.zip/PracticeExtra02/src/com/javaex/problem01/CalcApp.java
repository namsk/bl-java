package com.javaex.problem01;

public class CalcApp {

    public static void main(String[] args) {

    }
}
