package com.javaex.problem01;

public class Div extends Operator {


}
