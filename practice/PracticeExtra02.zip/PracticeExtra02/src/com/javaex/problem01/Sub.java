package com.javaex.problem01;

public class Sub extends Operator {


}
