package com.javaex.problem03;

public class Goods {

    private String name;
    private int price;
    private int count;
    
    
    
}
