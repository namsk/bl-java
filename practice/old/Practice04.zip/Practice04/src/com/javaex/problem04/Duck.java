package com.javaex.problem04;

public class Duck implements Soundable {


}
