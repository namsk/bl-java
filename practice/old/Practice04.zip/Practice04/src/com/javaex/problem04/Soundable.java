package com.javaex.problem04;

public interface Soundable {

    public String sound();
}
