package com.javaex.problem04;

public class Cat implements Soundable {


}
