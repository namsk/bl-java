package com.javaex.problem04;

public class Dog implements Soundable {


}
