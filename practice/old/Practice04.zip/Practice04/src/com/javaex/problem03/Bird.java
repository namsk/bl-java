package com.javaex.problem03;

public abstract class Bird {
    private String name;



}
