package com.javaex.problem03;

public class Sparrow extends Bird {



}
