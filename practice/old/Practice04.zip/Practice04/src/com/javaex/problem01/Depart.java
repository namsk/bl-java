package com.javaex.problem01;

public class Depart extends Employee {

    //코드작성

}
