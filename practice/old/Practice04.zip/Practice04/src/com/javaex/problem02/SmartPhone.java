package com.javaex.problem02;

public class SmartPhone extends MusicPhone {
    
    public void execute(String str){
        
        //코드작성
        
    }
 
    //메소드작성
    
    //메소드작성
    
    
    
}
