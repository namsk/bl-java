package com.javaex.problem04;


public class CConverterApp {

    public static void main(String[] args) {

        double dollar;
        double won;
        
        CConverter.setRate(1118.70);
        
        
        //백만원을 달러로 출력

        
        //100달려를 원으로 출력
        
        
    }

}
