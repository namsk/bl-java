package com.javaex.ex02;

public abstract class Bird {
    private String name;



}
