package com.javaex.ex02;

public class Sparrow extends Bird {



}
