package com.javaex.ex02;

public class Duck extends Bird {

    public void sing() {
    
    }

    public void fly() {
    
    }
    
    public void showName() {
    
    }

}
