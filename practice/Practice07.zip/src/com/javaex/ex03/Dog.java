package com.javaex.ex03;

public class Dog implements Soundable {


}
