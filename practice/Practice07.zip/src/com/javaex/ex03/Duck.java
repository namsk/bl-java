package com.javaex.ex03;

public class Duck implements Soundable {


}
