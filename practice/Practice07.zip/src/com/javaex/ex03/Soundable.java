package com.javaex.ex03;

public interface Soundable {

    public String sound();
}
