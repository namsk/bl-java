package com.javaex.ex03;

public class Cat implements Soundable {


}
