package com.javaex.ex03;

public class PointApp {

	public static void main(String[] args) {
		
		Point p = new Point(3, 3);
		
		System.out.println(p.toString());

	}

}


