package com.javaex.ex05;

public class CalcApp {

    public static void main(String[] args) {

    }
}
