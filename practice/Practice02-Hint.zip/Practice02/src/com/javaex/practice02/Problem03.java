package com.javaex.practice02;

public class Problem03 {

    public static void main(String[] args) {

        char c[] = {'T','h','i','s',' ','i','s',' ','a',' ','p','e','n','c','i','l'};  
        
        //문장 출력
        System.out.println(c);
        
        //배열의 검사하여 공백이면 콤마로 변경
        
        
        //문장 출력
       
        
        
    }
    
    
 

}
