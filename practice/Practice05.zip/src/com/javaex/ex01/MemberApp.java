package com.javaex.ex01;

public class MemberApp {

	public static void main(String[] args) {

		
	}

}
