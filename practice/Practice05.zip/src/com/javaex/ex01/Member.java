package com.javaex.ex01;

public class Member {

}
