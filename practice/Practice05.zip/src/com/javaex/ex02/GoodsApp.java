package com.javaex.ex02;

public class GoodsApp {

	public static void main(String[] args) {

		
	}

}


