package com.javaex.ex07;

public class Friend {

    private String name;
    private String hp;
    private String school;

    
    // getter/setter 작성
    
    
    
    public void showInfo(){
        System.out.println("이름:"+name+"  핸드폰:"+hp+"  학교:"+school);
    }

}
