package com.javaex.ex02;

public class Triangle extends Shape{
	
	
}


