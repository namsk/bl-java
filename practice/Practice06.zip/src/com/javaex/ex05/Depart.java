package com.javaex.ex05;

public class Depart {

	 //코드작성

}
