package com.javaex.ex04;

public class UserApp {

	public static void main(String[] args) {
		

	}

}
