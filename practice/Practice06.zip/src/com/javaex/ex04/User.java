package com.javaex.ex04;

public class User {
	
	
}
