package com.javaex.ex03;

public class ShapeApp {

	public static void main(String[] args) {
		
			Triangle t1 = new Triangle(5, 5);
			t1.setFillColor("빨강");
			t1.setLineColor("파랑");
			t1.showInfo();
			
	}

}


