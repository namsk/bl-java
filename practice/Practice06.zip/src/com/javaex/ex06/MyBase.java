package com.javaex.ex06;

public class MyBase extends Base{

    //코드작성
    
}
