package com.javaex.ex01;

public class Customer extends Person{
	

	
}
