package com.javaex.practice;

public class Problem05 {

	public static void main(String[] args) {

		for(int i=1; ___  ; i++) { //가로축 반복조건
			
		    //세로축 반복조건
			System.out.println("");
		}
		
	}

}
