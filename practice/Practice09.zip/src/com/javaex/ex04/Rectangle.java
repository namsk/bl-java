package com.javaex.ex04;

public class Rectangle {
    private double width;
    private double height;

}