package com.javaex.ex04;

public interface Resizeable {
	
    public void resize(double s);
    
}
