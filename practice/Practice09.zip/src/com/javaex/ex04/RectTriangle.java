package com.javaex.ex04;

public class RectTriangle {
    private double width;
    private double height;

    
}