package com.javaex.ex02;


public class FriendApp {

    public static void main(String[] args) {


    	
    	
    }

}
