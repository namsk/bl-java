package com.javaex.ex02;

public class Friend {

    private String name;
    private String hp;
    private String school;



}
