package com.javaex.ex03;

public class Goods {

	private String name;
	private int price;
	private int count;

	

}
