package com.javaex.basic.var;

public class BooleanEx {
	public static void main(String[] args) {
		boolean b1 = true;
		boolean b2 = false;
		
		System.out.println(b1);
		System.out.println(b2);
		
		boolean result;
		
		int var1 = 3;
		int var2 = 5;
		
		result = var1 < var2;
		
		System.out.println(var1 + "<" + var2 
				+ "=" +result);
	}
}
