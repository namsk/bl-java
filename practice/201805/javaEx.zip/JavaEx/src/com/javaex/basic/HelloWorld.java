package com.javaex.basic;

/*
 * Hello World 출력 프로그램
 * 여러줄 주석
 */
public class HelloWorld {
	public static void main(String[] args) {
		System.out.println("Hello World");
		//	Hello World를 화면에 출력한다
	}
}
