package com.javaex.api.generic.ex1;

//	모든 객체를 담을 수 있는 Box 하나 설계
public class Box {
	Object content;
	
	public Object getContent() {
		return content;
	}
	
	public void setContent(Object content) {
		this.content = content;
	}

}
