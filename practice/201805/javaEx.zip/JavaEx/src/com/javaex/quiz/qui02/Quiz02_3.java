package com.javaex.quiz.qui02;

public class Quiz02_3 {
	public static void main(String[] args) {
		int num = 13579;
		
		System.out.println(num / 100 * 100);
	}
}
