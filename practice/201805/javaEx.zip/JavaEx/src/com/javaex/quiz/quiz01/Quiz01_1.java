package com.javaex.quiz.quiz01;

public class Quiz01_1 {
	public static void main(String[] args) {
		String phoneNumber = "010-9897-1435";
		
		System.out.println(phoneNumber);
	}
}
