package com.javaex.quiz.quiz01;

public class Quiz01_3 {
	public static void main(String[] args) {
		System.out.println("1" + "3");
		System.out.println(true + "Java");
		System.out.println('A' + 'B');
		System.out.println('1' + 2);
		System.out.println('J' + "ava");
//		System.out.println(false + null);	//	오류
	}
}
