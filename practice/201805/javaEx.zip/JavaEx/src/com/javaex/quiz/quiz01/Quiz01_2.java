package com.javaex.quiz.quiz01;

public class Quiz01_2 {
	public static void main(String[] args) {
		float interestRate = 0.031f;
	}
}
