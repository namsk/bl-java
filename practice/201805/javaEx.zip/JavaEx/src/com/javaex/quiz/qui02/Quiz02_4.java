package com.javaex.quiz.qui02;

public class Quiz02_4 {
	public static void main(String[] args) {
		char ch = 'A';
		
		//	'A': 65, 'a': 97
		char conv = (char)(ch + 32);
		
		System.out.println(conv);
		System.out.println((char)(ch + 32));
	}
}
