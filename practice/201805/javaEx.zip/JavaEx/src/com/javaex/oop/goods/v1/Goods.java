package com.javaex.oop.goods.v1;

public class Goods {
	//	필드 선언
	String name;
	int price;
}
