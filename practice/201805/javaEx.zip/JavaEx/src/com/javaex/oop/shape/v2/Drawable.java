package com.javaex.oop.shape.v2;

public interface Drawable {
	public void draw();
}
