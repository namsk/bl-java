package com.javaex.problem02;

public class Base {
    
    public void service(String state) {
        //코드작성
    	if (state == "낮") {
    		day();
    	} else if (state == "밤") {
    		night();
    	} else if (state == "오후") {
    		afternoon();
    	}
    }

    private void day() {
        System.out.println("낮에는 열심히 일하자");
    }

    private void night() {
        //
    	System.out.println("night");
    }
    
    private void afternoon(){
        System.out.println("오후도 낮과 마찬가지로 일해야 합니다.");
    }

}
