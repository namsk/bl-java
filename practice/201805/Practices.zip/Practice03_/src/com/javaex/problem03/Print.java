package com.javaex.problem03;

public class Print {
    
    public void printer(int val){
        System.out.println(val);
    }

    //메소드  작성
    public void printer(boolean val) {
    	System.out.println(val);
    }
    
    public void printer(double val) {
    	System.out.println(val);
    }
    
    public void printer(String val) {
    	System.out.println(val);
    }
}
