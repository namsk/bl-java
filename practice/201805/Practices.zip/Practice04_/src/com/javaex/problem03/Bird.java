package com.javaex.problem03;

public abstract class Bird {
    private String name;

    public void setName(String name) {
    	this.name = name;
    }
    
    protected String getName() {
    	return name;
    }

    public abstract void showName();
    public abstract void fly();
    public abstract void sing();
}
