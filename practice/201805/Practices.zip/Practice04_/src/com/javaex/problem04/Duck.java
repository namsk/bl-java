package com.javaex.problem04;

public class Duck implements Soundable {

	@Override
	public String sound() {
		return "꽥꽥";
	}


}
