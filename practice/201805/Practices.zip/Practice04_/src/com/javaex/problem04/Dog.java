package com.javaex.problem04;

public class Dog implements Soundable {

	@Override
	public String sound() {
		return "멍멍";
	}


}
