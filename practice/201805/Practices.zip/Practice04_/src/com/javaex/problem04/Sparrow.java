package com.javaex.problem04;

public class Sparrow implements Soundable {

	@Override
	public String sound() {
		return "짹짹";
	}


}
