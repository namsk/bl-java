package com.javaex.problem04;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class SoundApp {

    public static void main(String[] args) {
        printSound( new Cat() );
        printSound( new Dog() );
        printSound( new Sparrow() );
        printSound( new Duck() );
    }

    public static void printSound( Soundable soundable ) {
        //구현
    	if (soundable instanceof Cat) {
    		System.out.println(((Cat)soundable).sound());
    	} else if (soundable instanceof Dog) {
    		System.out.println(((Dog)soundable).sound());
    	} else if (soundable instanceof Sparrow) {
    		System.out.println(((Sparrow)soundable).sound());
    	} else if (soundable instanceof Duck) {
    		System.out.println(((Duck)soundable).sound());
    	}
    	
    	/*
    	 * 아래는 Reflection 버전
    	 */
    	/*
    	Class cls = soundable.getClass();
    	Method methods[] = cls.getDeclaredMethods();
    	for (Method method:methods) {
    		if (method.getName().equals("sound")) {
    			try {
					String sound = (String)method.invoke(soundable);
					System.out.println(sound);
				} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
					e.printStackTrace();
				}
    		}
    	}
    	*/
    	
    }
    
}
