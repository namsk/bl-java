package com.javaex.problem02;

public class SmartPhone extends MusicPhone {
    
    public void execute(String str){
        
        //코드작성
    	if (str.equals("앱")) {
    		launchApp();
    	} else if (str.equals("음악")) {
    		playMusic();
    	} else {
    		super.execute(str);
    	}
    }
 
    //메소드작성
    protected void launchApp() {
    	System.out.println("앱 실행");
    }
    //메소드작성
    protected void playMusic() {
    	System.out.println("다운로드하여 음악 재생");
    }
}
