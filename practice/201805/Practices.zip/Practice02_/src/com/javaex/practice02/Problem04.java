package com.javaex.practice02;

import java.util.Scanner;

public class Problem04 {

    public static void main(String[] args) {

    		int[] no = new int[6];
        
        int idx = 0;
        
        while (idx < no.length) {
        		int choice = (int)(Math.random() * 45) + 1;
        		boolean isDuplicated = false;
        		
        		for (int i = 0; i < idx; i++) {
        			if (choice == no[i]) {
        				isDuplicated = true;
        				break;
        			}
        		}
        		
        		if (isDuplicated) {
        			continue;
        		}
        		
        		no[idx] = choice;
        		idx++;
        }
        
        for(int i = 0; i < no.length; i++){
            System.out.print(no[i] + "  ");
        }
        System.out.println();
    }

}
