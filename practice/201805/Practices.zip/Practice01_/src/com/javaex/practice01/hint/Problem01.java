package com.javaex.practice01.hint;

public class Problem01 {

	public static void main(String[] args) {
		int i;
		
		for (i = 1; i <= 100  ; i++) { 
			if ( i % 5 == 0 && i % 7 == 0) {
				System.out.println(i);
			}
		}
		
	}

}
