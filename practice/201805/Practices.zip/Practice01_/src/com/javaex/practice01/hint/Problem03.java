package com.javaex.practice01.hint;

public class Problem03 {
	
	public static void main(String[] args){
		
		for (int i = 1; i <= 9; i++) { //가로 반복조건
			for (int dan = 2; dan <= 9; dan++) { //세로 반복조건
				System.out.print(dan +"*"+ i + "=" + dan*i);
				System.out.print("\t");
			}
			
			System.out.println();
		}
		
	}

}
