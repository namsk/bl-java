package com.javaex.practice01.hint;

import java.util.Scanner;

public class Problem06 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("숫자를 입력하세요");
		int num = sc.nextInt();
		int i;
		int startNum;
		int sum = 0 ;
		
		startNum = (num % 2 == 0) ? 2 : 1; //	3항 연산
		
		//코드작성
		for (i = startNum; i <= num; i += 2) {
			sum += i;
		}
		
		System.out.println("결과값: " + sum);
		sc.close();
	}
}
