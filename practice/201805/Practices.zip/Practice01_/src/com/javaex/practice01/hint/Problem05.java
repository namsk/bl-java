package com.javaex.practice01.hint;

public class Problem05 {

	public static void main(String[] args) {

		for (int i = 1; i <= 10  ; i++) { //가로축 반복조건
			
			for (int j = 0; j < 10; j++) {
				System.out.print(i + j);
				System.out.print("\t");
			}
			System.out.println();
		}
		
	}

}
